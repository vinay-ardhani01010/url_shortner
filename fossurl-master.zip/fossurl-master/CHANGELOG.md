#### Change Log:

**2.0**
* New Design
* Speed Improved
* Removed Bootstrap and JQuery
* Rewritten in ES6 and transpiled using Babel for supporting old browsers

**2.0 alpha**
* Added custom url support
* Changed background to gradient